"use client";

import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

/** Colour scale for subject grade points (emerald → rose, no indigo/blue). */
export function gpTone(gp: number): string {
  if (gp >= 5) return "bg-emerald-100 text-emerald-800 border-emerald-200";
  if (gp >= 4) return "bg-green-100 text-green-800 border-green-200";
  if (gp >= 3.5) return "bg-teal-100 text-teal-800 border-teal-200";
  if (gp >= 3) return "bg-amber-100 text-amber-800 border-amber-200";
  if (gp >= 2) return "bg-orange-100 text-orange-800 border-orange-200";
  if (gp >= 1) return "bg-yellow-100 text-yellow-800 border-yellow-200";
  return "bg-rose-100 text-rose-800 border-rose-200";
}

export function letterTone(letter: string): string {
  switch (letter) {
    case "A+": return "bg-emerald-600 text-white border-emerald-600";
    case "A": return "bg-green-600 text-white border-green-600";
    case "A-": return "bg-teal-600 text-white border-teal-600";
    case "B": return "bg-amber-500 text-white border-amber-500";
    case "C": return "bg-orange-500 text-white border-orange-500";
    case "D": return "bg-yellow-600 text-white border-yellow-600";
    default: return "bg-rose-600 text-white border-rose-600";
  }
}

export function GpChip({ gp, absent }: { gp: number; absent?: boolean }) {
  if (absent) {
    return (
      <span className="inline-flex items-center justify-center min-w-[2.4rem] rounded-md border border-slate-300 bg-slate-100 px-1.5 py-0.5 text-xs font-bold text-slate-700">
        AB
      </span>
    );
  }
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center min-w-[2.4rem] rounded-md border px-1.5 py-0.5 text-xs font-semibold",
        gpTone(gp)
      )}
    >
      {gp.toFixed(1)}
    </span>
  );
}

export function LetterBadge({ letter, className }: { letter: string; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-md border px-2 py-0.5 text-sm font-bold",
        letterTone(letter),
        className
      )}
    >
      {letter}
    </span>
  );
}

export function StatCard({
  label,
  value,
  sub,
  tone = "default",
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: "default" | "good" | "warn" | "bad";
}) {
  const toneRing =
    tone === "good"
      ? "border-emerald-200 bg-emerald-50"
      : tone === "warn"
        ? "border-amber-200 bg-amber-50"
        : tone === "bad"
          ? "border-rose-200 bg-rose-50"
          : "border-slate-200 bg-white";
  return (
    <div className={cn("rounded-xl border p-4 shadow-sm", toneRing)}>
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-bold text-slate-900">{value}</p>
      {sub ? <p className="mt-0.5 text-xs text-slate-500">{sub}</p> : null}
    </div>
  );
}

export function SectionTitle({
  title,
  desc,
  right,
}: {
  title: string;
  desc?: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">{title}</h2>
        {desc ? <p className="mt-1 text-sm text-slate-500">{desc}</p> : null}
      </div>
      {right}
    </div>
  );
}

export function ListBadge({ label, tone }: { label: string; tone: string }) {
  return <Badge variant="outline" className={cn("text-[11px]", tone)}>{label}</Badge>;
}

export const OPTIONAL_LIST_TONE = "border-amber-300 bg-amber-50 text-amber-800";
export const PRACTICAL_LIST_TONE = "border-rose-300 bg-rose-50 text-rose-800";
export const ABSENT_LIST_TONE = "border-slate-300 bg-slate-100 text-slate-700";
