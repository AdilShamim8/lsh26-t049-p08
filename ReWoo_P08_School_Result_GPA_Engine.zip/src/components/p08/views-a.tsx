"use client";

import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CLASSES,
  SUBJECTS,
  getAllResults,
  getResultsByClass,
  getResultById,
  EDGE_STUDENTS_ONLY,
} from "@/lib/p08/data";
import {
  PRACTICAL_PASS,
  PRACTICAL_MAX,
  THEORY_PASS,
  THEORY_MAX,
  summarizeClass,
} from "@/lib/p08/engine";
import {
  GpChip,
  LetterBadge,
  StatCard,
  SectionTitle,
  ListBadge,
  OPTIONAL_LIST_TONE,
  PRACTICAL_LIST_TONE,
  ABSENT_LIST_TONE,
} from "./ui-bits";

// ---------------------------------------------------------------------------
// DASHBOARD
// ---------------------------------------------------------------------------

export function DashboardView({
  onOpenStudent,
  onGoLists,
  onGoSummary,
}: {
  onOpenStudent: (id: string) => void;
  onGoLists: () => void;
  onGoSummary: () => void;
}) {
  const results = useMemo(() => getAllResults(), []);
  const passed = results.filter((r) => !r.compulsoryFailed);
  const overallPassRate = ((passed.length / results.length) * 100).toFixed(1);
  const aPlus = results.filter((r) => r.letter === "A+").length;
  const optionalList = results.filter((r) => r.checking.optionalList);
  const practicalList = results.filter((r) => r.checking.practicalFailList);
  const absentList = results.filter((r) => r.checking.absentList);

  return (
    <div className="space-y-8">
      <section>
        <SectionTitle
          title="Result dashboard"
          desc="Bogura Secondary School — every number below is computed live by the rule engine from the seeded marks (R1: 64 students, 2 classes, 6 compulsory + 1 optional subject each)."
        />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          <StatCard label="Students" value={String(results.length)} sub="across 2 classes" />
          <StatCard label="Pass rate" value={`${overallPassRate}%`} sub={`${passed.length} of ${results.length} pass`} tone="good" />
          <StatCard label="A+ grades" value={String(aPlus)} sub="final letter A+" tone="good" />
          <StatCard label="Optional list" value={String(optionalList.length)} sub="R-29 checking list" tone="warn" />
          <StatCard label="Practical fail" value={String(practicalList.length)} sub="R-29 checking list" tone="bad" />
          <StatCard label="Absent (AB)" value={String(absentList.length)} sub="R-29 checking list" tone="warn" />
        </div>
        <div className="mt-3 flex flex-wrap gap-2 print:hidden">
          <Button variant="outline" size="sm" onClick={onGoLists}>Open checking lists</Button>
          <Button variant="outline" size="sm" onClick={onGoSummary}>Class summary</Button>
        </div>
      </section>

      <section>
        <SectionTitle
          title="Hard-edge students"
          desc="Ten deliberately seeded boundary cases (R1 requires at least 8). Click any student to open the full calculation trace."
        />
        <div className="grid gap-3 md:grid-cols-2">
          {EDGE_STUDENTS_ONLY.map((s) => {
            const r = getResultById(s.id)!;
            return (
              <button
                key={s.id}
                onClick={() => onOpenStudent(s.id)}
                className="group rounded-xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:border-emerald-300 hover:shadow-md"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900 group-hover:text-emerald-700">
                      {s.name}
                    </span>
                    <Badge variant="outline" className="text-[11px] text-slate-500">
                      {r.className} · Roll {s.roll}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <LetterBadge letter={r.letter} />
                    <span className="text-sm font-semibold text-slate-700">
                      GPA {r.finalGpa.toFixed(2)}
                    </span>
                  </div>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-slate-500">{s.edgeNote}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section className="print:hidden">
        <SectionTitle
          title="Rules used by the engine"
          desc="The engine implements ONLY these published rules — nothing else."
        />
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Grade scale & letters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-xs uppercase text-slate-500">
                    <th className="py-1">Mark</th>
                    <th className="py-1">Grade point</th>
                    <th className="py-1">Final GPA → Letter (R-10)</th>
                  </tr>
                </thead>
                <tbody className="font-medium text-slate-700">
                  {[
                    ["80 and above", "5.0"],
                    ["70 – 79", "4.0"],
                    ["60 – 69", "3.5"],
                    ["50 – 59", "3.0"],
                    ["40 – 49", "2.0"],
                    ["33 – 39", "1.0"],
                    ["Below 33", "0.0 + fail"],
                  ].map(([m, g]) => (
                    <tr key={m} className="border-t border-slate-100">
                      <td className="py-1">{m}</td>
                      <td className="py-1">{g}</td>
                      <td className="py-1 text-slate-400" rowSpan={g === "5.0" ? 7 : undefined}>
                        {g === "5.0" ? (
                          <ul className="space-y-0.5 font-normal text-slate-600">
                            <li>5.00 → A+</li>
                            <li>4.00–4.99 → A</li>
                            <li>3.50–3.99 → A-</li>
                            <li>3.00–3.49 → B</li>
                            <li>2.00–2.99 → C</li>
                            <li>1.00–1.99 → D</li>
                            <li>Fail → F</li>
                          </ul>
                        ) : null}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">R-11 — Practical subjects</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-slate-600">
                Theory out of <b>{THEORY_MAX}</b> (pass ≥ {THEORY_PASS}); practical out of{" "}
                <b>{PRACTICAL_MAX}</b> (pass ≥ {PRACTICAL_PASS}). The student must pass{" "}
                <b>both parts separately</b>; failing either gives grade point 0. When both pass,
                the grade is computed from theory + practical.
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">R-12 — Absence</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-slate-600">
                Absent in a compulsory subject → <b>AB</b>, grade point 0, overall result{" "}
                <b>F</b>. Absent in the optional subject → contributes 0 and the student appears
                on the checking lists. <b>AB is never shown or treated like a zero mark.</b>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">R-13 — GPA formula</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-slate-600">
                GPA = (Σ compulsory grade points + max(0, optional grade point − 2)) / 6, capped
                at <b>5.00</b>, shown to 2 decimals. Any compulsory failure → final GPA{" "}
                <b>0.00</b>, letter <b>F</b>, with the uncancelled average kept visible in the
                trace.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// CLASSES
// ---------------------------------------------------------------------------

export function ClassesView({ onOpenStudent }: { onOpenStudent: (id: string) => void }) {
  const [classId, setClassId] = useState(CLASSES[0].id);
  const results = useMemo(() => getResultsByClass(classId), [classId]);
  const optionalShort = (optId: string) =>
    SUBJECTS.find((s) => s.id === optId)?.short ?? optId;

  return (
    <div>
      <SectionTitle
        title="Classes"
        desc="Roll, name, grade point per subject (optional last), final GPA and letter. Click a row for the full trace."
      />
      <div className="mb-4 flex flex-wrap gap-2 print:hidden">
        {CLASSES.map((c) => (
          <Button
            key={c.id}
            size="sm"
            variant={classId === c.id ? "default" : "outline"}
            onClick={() => setClassId(c.id)}
            className={classId === c.id ? "bg-emerald-700 hover:bg-emerald-800" : ""}
          >
            {c.name}
          </Button>
        ))}
      </div>
      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full min-w-[820px] text-sm">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
              <th className="px-3 py-2">Roll</th>
              <th className="px-3 py-2">Student</th>
              <th className="px-2 py-2 text-center">BAN</th>
              <th className="px-2 py-2 text-center">ENG</th>
              <th className="px-2 py-2 text-center">MATH</th>
              <th className="px-2 py-2 text-center">SCI</th>
              <th className="px-2 py-2 text-center">BGS</th>
              <th className="px-2 py-2 text-center">REL</th>
              <th className="px-2 py-2 text-center">Optional</th>
              <th className="px-3 py-2 text-center">GPA</th>
              <th className="px-3 py-2 text-center">Letter</th>
              <th className="px-3 py-2 text-center">Status</th>
            </tr>
          </thead>
          <tbody>
            {results.map((r) => (
              <tr
                key={r.student.id}
                onClick={() => onOpenStudent(r.student.id)}
                className="cursor-pointer border-b border-slate-100 transition hover:bg-emerald-50/60"
              >
                <td className="px-3 py-2 font-mono text-xs text-slate-500">{r.student.roll}</td>
                <td className="px-3 py-2">
                  <span className="font-medium text-slate-800">{r.student.name}</span>
                  {r.student.edgeNote ? (
                    <span title={r.student.edgeNote} className="ml-1 text-amber-500" aria-label="Hard edge student">
                      ★
                    </span>
                  ) : null}
                  <span className="block text-[11px] text-slate-400">
                    Optional: {r.optionalSubjectName}
                  </span>
                </td>
                {r.traces.map((t) => (
                  <td key={t.subjectId} className="px-2 py-2 text-center">
                    <GpChip gp={t.gradePoint} absent={t.absent} />
                  </td>
                ))}
                <td className="px-3 py-2 text-center font-semibold text-slate-800">
                  {r.finalGpa.toFixed(2)}
                </td>
                <td className="px-3 py-2 text-center">
                  <LetterBadge letter={r.letter} />
                </td>
                <td className="px-3 py-2 text-center">
                  {r.compulsoryFailed ? (
                    <Badge className="border-rose-200 bg-rose-100 text-rose-800 hover:bg-rose-100" variant="outline">
                      FAIL
                    </Badge>
                  ) : (
                    <Badge className="border-emerald-200 bg-emerald-100 text-emerald-800 hover:bg-emerald-100" variant="outline">
                      PASS
                    </Badge>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-xs text-slate-400">
        ★ = deliberately seeded hard-edge case · Grade point chips: AB = absent (never a zero mark)
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------------
// STUDENT TRACE
// ---------------------------------------------------------------------------

export function TraceView({
  studentId,
  onSelectStudent,
}: {
  studentId: string | null;
  onSelectStudent: (id: string) => void;
}) {
  const results = useMemo(() => getAllResults(), []);
  const [classId, setClassId] = useState<string>(CLASSES[0].id);
  const current = studentId ? getResultById(studentId) : undefined;
  const classStudents = results.filter((r) => r.student.classId === classId);

  const handleClass = (cid: string) => {
    setClassId(cid);
    const first = results.find((r) => r.student.classId === cid);
    if (first) onSelectStudent(first.student.id);
  };

  return (
    <div>
      <SectionTitle
        title="Student result & calculation trace"
        desc="For every subject: the exact mark used, the grade point produced, and the rule that decided it (R3)."
        right={
          <Button variant="outline" size="sm" className="print:hidden" onClick={() => window.print()}>
            Print marksheet
          </Button>
        }
      />

      <div className="mb-5 flex flex-col gap-3 sm:flex-row print:hidden">
        <div className="w-full sm:w-64">
          <Select value={classId} onValueChange={handleClass}>
            <SelectTrigger aria-label="Select class"><SelectValue placeholder="Class" /></SelectTrigger>
            <SelectContent>
              {CLASSES.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-full sm:w-72">
          <Select
            value={current && current.student.classId === classId ? current.student.id : classStudents[0]?.student.id ?? ""}
            onValueChange={onSelectStudent}
          >
            <SelectTrigger aria-label="Select student"><SelectValue placeholder="Student" /></SelectTrigger>
            <SelectContent>
              {classStudents.map((r) => (
                <SelectItem key={r.student.id} value={r.student.id}>
                  Roll {r.student.roll} — {r.student.name}
                  {r.student.edgeNote ? " ★" : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {current ? (
        <div className="space-y-5">
          {/* Student header */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900">{current.student.name}</h3>
                <p className="text-sm text-slate-500">
                  {current.className} · Roll {current.student.roll} · Optional subject:{" "}
                  {current.optionalSubjectName}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-xs uppercase tracking-wide text-slate-400">Final GPA</p>
                  <p className="text-3xl font-bold text-slate-900">{current.finalGpa.toFixed(2)}</p>
                </div>
                <LetterBadge letter={current.letter} className="px-3 py-1 text-lg" />
              </div>
            </div>
            {current.student.edgeNote ? (
              <p className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                ★ Hard-edge case: {current.student.edgeNote}
              </p>
            ) : null}
          </div>

          {/* Subject traces */}
          <div className="grid gap-3 lg:grid-cols-2">
            {current.traces.map((t) => (
              <div
                key={t.subjectId}
                className={`rounded-xl border bg-white p-4 shadow-sm ${
                  t.passed ? "border-slate-200" : "border-rose-300"
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900">{t.subjectName}</span>
                    <Badge variant="outline" className="text-[10px] text-slate-500">
                      {t.compulsory ? "COMPULSORY" : "OPTIONAL (4th)"}
                    </Badge>
                  </div>
                  <GpChip gp={t.gradePoint} absent={t.absent} />
                </div>

                <div className="mt-2 text-sm text-slate-700">
                  {t.absent ? (
                    <p>
                      <span className="inline-flex items-center rounded-md border border-slate-300 bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-700">AB</span>
                      <span className="ml-2 text-slate-500">Absent — not a zero mark</span>
                    </p>
                  ) : t.hasPractical ? (
                    <p>
                      Theory <b>{t.theory}/{t.theoryMax}</b> · Practical{" "}
                      <b>{t.practical}/{t.practicalMax}</b> · Total used{" "}
                      <b>{t.markUsed !== null ? t.markUsed : "—"}/100</b>
                    </p>
                  ) : (
                    <p>
                      Mark <b>{t.markUsed}/{t.theoryMax}</b>
                    </p>
                  )}
                </div>

                {!t.passed && t.failureReason && !t.absent ? (
                  <p className="mt-1 text-sm font-medium text-rose-700">FAIL — {t.failureReason}</p>
                ) : null}
                {!t.passed && t.absent && t.compulsory ? (
                  <p className="mt-1 text-sm font-medium text-rose-700">
                    Fails the subject (compulsory absence → overall result F)
                  </p>
                ) : null}

                <p className="mt-2 rounded-lg bg-slate-50 px-3 py-2 font-mono text-[11px] leading-relaxed text-slate-600">
                  {t.ruleText}
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  Contributes{" "}
                  <b className="text-slate-700">
                    {t.contribution.toFixed(1)}
                  </b>{" "}
                  {t.compulsory ? "(full grade point)" : `= max(0, ${t.gradePoint.toFixed(1)} − 2) to GPA`}
                </p>
              </div>
            ))}
          </div>

          {/* GPA walk-through */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h4 className="font-semibold text-slate-900">GPA calculation walk-through (R-13)</h4>
            <div className="mt-3 space-y-1.5 font-mono text-sm text-slate-700">
              <p>Σ compulsory grade points (6 subjects) = {current.compulsorySum.toFixed(1)}</p>
              <p>
                Optional ({current.optionalSubjectName}) GP = {current.optionalGradePoint.toFixed(1)}{" "}
                → contribution = max(0, {current.optionalGradePoint.toFixed(1)} − 2) ={" "}
                {current.optionalContribution.toFixed(1)}
              </p>
              <p>
                ({current.compulsorySum.toFixed(1)} + {current.optionalContribution.toFixed(1)}) / 6 ={" "}
                {current.uncancelledRaw.toFixed(2)} → capped at 5.00 →{" "}
                <b>uncancelled GPA {current.uncancelledGpa.toFixed(2)}</b>
              </p>
            </div>

            {current.compulsoryFailed ? (
              <div className="mt-4 rounded-lg border border-rose-200 bg-rose-50 p-4">
                <p className="font-semibold text-rose-800">
                  Final GPA 0.00 · Letter F — compulsory subject failure
                </p>
                <ul className="mt-1 list-inside list-disc text-sm text-rose-700">
                  {current.failedCompulsorySubjects.map((f) => (
                    <li key={f.subject}>
                      <b>{f.subject}</b> — {f.reason}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-sm text-rose-700">
                  The uncancelled average <b>{current.uncancelledGpa.toFixed(2)}</b> is retained
                  above in the trace, as required.
                </p>
              </div>
            ) : (
              <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 p-4">
                <p className="font-semibold text-emerald-800">
                  Final GPA {current.finalGpa.toFixed(2)} · Letter {current.letter} — passed all
                  compulsory subjects
                </p>
              </div>
            )}

            {current.checking.reasons.length > 0 ? (
              <div className="mt-4 space-y-1">
                <p className="text-sm font-semibold text-slate-700">Appears on checking lists:</p>
                <div className="flex flex-wrap gap-2">
                  {current.checking.optionalList ? (
                    <ListBadge label="Optional-subject rule" tone={OPTIONAL_LIST_TONE} />
                  ) : null}
                  {current.checking.practicalFailList ? (
                    <ListBadge label="Practical fail" tone={PRACTICAL_LIST_TONE} />
                  ) : null}
                  {current.checking.absentList ? (
                    <ListBadge label="Absent (AB)" tone={ABSENT_LIST_TONE} />
                  ) : null}
                </div>
                <ul className="mt-1 list-inside list-disc text-xs text-slate-500">
                  {current.checking.reasons.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            ) : (
              <p className="mt-4 text-sm text-slate-400">Not on any checking list.</p>
            )}
          </div>
        </div>
      ) : (
        <p className="text-sm text-slate-500">Select a student to view the trace.</p>
      )}
    </div>
  );
}
