"use client";

import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  CLASSES,
  ENGINE_CTX,
  SUBJECTS,
  getAllResults,
} from "@/lib/p08/data";
import { computeStudentResult, summarizeClass, StudentResult } from "@/lib/p08/engine";
import { SectionTitle, LetterBadge } from "./ui-bits";

// ---------------------------------------------------------------------------
// CHECKING LISTS (R4 / R-29)
// ---------------------------------------------------------------------------

function CheckingRow({
  result,
  onOpenStudent,
}: {
  result: StudentResult;
  onOpenStudent: (id: string) => void;
}) {
  const r = result;
  const multi =
    [r.checking.optionalList, r.checking.practicalFailList, r.checking.absentList].filter(
      Boolean
    ).length > 1;
  return (
    <tr
      onClick={() => onOpenStudent(r.student.id)}
      className="cursor-pointer border-b border-slate-100 transition hover:bg-emerald-50/60"
    >
      <td className="px-3 py-2">
        <span className="font-medium text-slate-800">{r.student.name}</span>
        <span className="block text-[11px] text-slate-400">
          {r.className} · Roll {r.student.roll}
        </span>
      </td>
      <td className="px-3 py-2 text-xs text-slate-600">
        <ul className="list-inside list-disc space-y-0.5">
          {r.checking.reasons.map((x, i) => (
            <li key={i}>{x}</li>
          ))}
        </ul>
      </td>
      <td className="px-3 py-2 text-center">
        <Badge variant="outline" className="text-[10px] text-slate-500">
          {r.letter} · {r.finalGpa.toFixed(2)}
        </Badge>
        {multi ? (
          <span className="mt-1 block text-[10px] font-medium text-amber-600">on multiple lists</span>
        ) : null}
      </td>
    </tr>
  );
}

function ListCard({
  title,
  rule,
  count,
  results,
  tone,
  onOpenStudent,
}: {
  title: string;
  rule: string;
  count: number;
  results: StudentResult[];
  tone: string;
  onOpenStudent: (id: string) => void;
}) {
  return (
    <Card className={tone}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between text-base">
          <span>{title}</span>
          <Badge className="bg-white text-slate-700">{count}</Badge>
        </CardTitle>
        <p className="text-xs text-slate-500">{rule}</p>
      </CardHeader>
      <CardContent>
        {results.length === 0 ? (
          <p className="py-4 text-center text-sm text-slate-400">No students on this list.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase text-slate-400">
                  <th className="py-1 pr-3">Student</th>
                  <th className="py-1 pr-3">Why they are listed</th>
                  <th className="py-1 text-center">Result</th>
                </tr>
              </thead>
              <tbody>
                {results.map((r) => (
                  <CheckingRow key={r.student.id} result={r} onOpenStudent={onOpenStudent} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function ListsView({ onOpenStudent }: { onOpenStudent: (id: string) => void }) {
  const results = useMemo(() => getAllResults(), []);
  const optionalList = results.filter((r) => r.checking.optionalList);
  const practicalList = results.filter((r) => r.checking.practicalFailList);
  const absentList = results.filter((r) => r.checking.absentList);

  return (
    <div>
      <SectionTitle
        title="Pre-publication checking lists"
        desc="Every student whose result was affected by the optional rule, a practical fail, or an absence (R4). A student can appear on more than one list. Click a row to inspect the trace."
      />
      <div className="space-y-5">
        <ListCard
          title="1 · Optional-subject list"
          rule="R-29: optional grade point 2.0 or below (an absent optional subject counts) — the optional subject did not help the GPA."
          count={optionalList.length}
          results={optionalList}
          tone="border-amber-200"
          onOpenStudent={onOpenStudent}
        />
        <ListCard
          title="2 · Practical fail list"
          rule="R-29: practical mark below 8 in any subject with a practical component."
          count={practicalList.length}
          results={practicalList}
          tone="border-rose-200"
          onOpenStudent={onOpenStudent}
        />
        <ListCard
          title="3 · Absent list"
          rule="R-29: AB in any subject (compulsory or optional)."
          count={absentList.length}
          results={absentList}
          tone="border-slate-200"
          onOpenStudent={onOpenStudent}
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// CLASS SUMMARY (bonus)
// ---------------------------------------------------------------------------

const LETTERS = ["A+", "A", "A-", "B", "C", "D", "F"];
const LETTER_BAR: Record<string, string> = {
  "A+": "bg-emerald-500",
  A: "bg-green-500",
  "A-": "bg-teal-500",
  B: "bg-amber-400",
  C: "bg-orange-400",
  D: "bg-yellow-500",
  F: "bg-rose-500",
};

export function SummaryView() {
  const results = useMemo(() => getAllResults(), []);
  const stats = useMemo(() => CLASSES.map((c) => summarizeClass(results, c.id)), [results]);
  const maxFail = Math.max(1, ...stats.flatMap((s) => s.subjectFailureCounts.map((f) => f.failures)));

  return (
    <div>
      <SectionTitle
        title="Class summary"
        desc="Pass rate, grade distribution and the subject causing the most failures, per class (bonus feature)."
      />
      <div className="grid gap-5 lg:grid-cols-2">
        {stats.map((s) => (
          <Card key={s.classId}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{s.className}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="rounded-lg border border-slate-200 p-3">
                  <p className="text-[11px] uppercase text-slate-400">Students</p>
                  <p className="text-xl font-bold">{s.students}</p>
                </div>
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3">
                  <p className="text-[11px] uppercase text-emerald-600">Pass rate</p>
                  <p className="text-xl font-bold text-emerald-700">{s.passRate}%</p>
                </div>
                <div className="rounded-lg border border-slate-200 p-3">
                  <p className="text-[11px] uppercase text-slate-400">Avg GPA (passed)</p>
                  <p className="text-xl font-bold">{s.averageGpa.toFixed(2)}</p>
                </div>
                <div className="rounded-lg border border-slate-200 p-3">
                  <p className="text-[11px] uppercase text-slate-400">A+ count</p>
                  <p className="text-xl font-bold">{s.aPlusCount}</p>
                </div>
              </div>

              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Grade distribution
                </p>
                <div className="flex h-6 w-full overflow-hidden rounded-md">
                  {LETTERS.map((l) => {
                    const n = s.gradeDistribution[l] ?? 0;
                    if (n === 0) return null;
                    return (
                      <div
                        key={l}
                        className={`${LETTER_BAR[l]} flex items-center justify-center text-[10px] font-bold text-white`}
                        style={{ width: `${(n / s.students) * 100}%` }}
                        title={`${l}: ${n}`}
                      >
                        {n}
                      </div>
                    );
                  })}
                </div>
                <div className="mt-1 flex flex-wrap gap-2 text-[11px] text-slate-500">
                  {LETTERS.map((l) => (
                    <span key={l}>
                      <span className={`mr-1 inline-block h-2 w-2 rounded-full align-middle ${LETTER_BAR[l]}`} />
                      {l}: {s.gradeDistribution[l] ?? 0}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Compulsory-subject failures
                </p>
                {s.subjectFailureCounts.length === 0 ? (
                  <p className="text-sm text-slate-400">No compulsory failures in this class.</p>
                ) : (
                  <div className="space-y-1.5">
                    {s.subjectFailureCounts.map((f) => (
                      <div key={f.subject} className="flex items-center gap-2 text-sm">
                        <span className="w-44 shrink-0 text-slate-600">{f.subject}</span>
                        <div className="h-3 flex-1 overflow-hidden rounded bg-slate-100">
                          <div
                            className="h-full bg-rose-400"
                            style={{ width: `${(f.failures / maxFail) * 100}%` }}
                          />
                        </div>
                        <span className="w-6 text-right font-semibold text-slate-700">
                          {f.failures}
                        </span>
                      </div>
                    ))}
                    {s.worstSubject ? (
                      <p className="pt-1 text-xs text-slate-500">
                        Subject with the most failures:{" "}
                        <b className="text-rose-600">{s.worstSubject.subject}</b> (
                        {s.worstSubject.failures} failure
                        {s.worstSubject.failures === 1 ? "" : "s"}).
                      </p>
                    ) : null}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// IMPORT / PASTE MARKS SHEET (bonus) — rejected rows with exact reasons
// ---------------------------------------------------------------------------

const CSV_HEADER =
  "roll,name,class,optional_subject,bangla,english,math,science_theory,science_practical,bgs,religion,optional_theory,optional_practical";

const SAMPLE_CSV = [
  CSV_HEADER,
  "901,Rashida Khatun,c9,phy,74,66,71,55,18,70,75,60,20",
  "902,Shafiq Islam,c10,geo,81,58,44,48,15,77,83,52,",
  "903,Bad Row,c9,art,70,70,70,50,15,70,70,70,20",
  "904,Bad Practical,c10,ict,70,70,70,50,26,70,70,60,18",
].join("\n");

interface ImportOutcome {
  accepted: { roll: number; name: string; gpa: number; letter: string }[];
  rejected: { row: number; reason: string }[];
}

function resolveClass(v: string): string | null {
  const s = v.trim().toLowerCase();
  if (["c9", "9", "class 9", "class9"].includes(s)) return "c9";
  if (["c10", "10", "class 10", "class10"].includes(s)) return "c10";
  return null;
}

function resolveSubject(v: string) {
  const s = v.trim().toLowerCase();
  return (
    SUBJECTS.find(
      (x) => !x.compulsory && (x.id === s || x.short.toLowerCase() === s || x.name.toLowerCase() === s)
    ) ?? null
  );
}

function parseMark(v: string, max: number, field: string): { ok: true; value: number | "AB" } | { ok: false; reason: string } {
  const s = v.trim();
  if (s.toUpperCase() === "AB") return { ok: true, value: "AB" };
  if (s === "") return { ok: false, reason: `${field} is empty (enter a mark or AB)` };
  const n = Number(s);
  if (!Number.isFinite(n)) return { ok: false, reason: `${field} '${s}' is not a number or AB` };
  if (n < 0 || n > max) return { ok: false, reason: `${field} '${s}' is out of range (0–${max})` };
  return { ok: true, value: Math.round(n) };
}

export function ImportView() {
  const [text, setText] = useState("");
  const [outcome, setOutcome] = useState<ImportOutcome | null>(null);
  const [ran, setRan] = useState(false);

  const run = () => {
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const accepted: ImportOutcome["accepted"] = [];
    const rejected: ImportOutcome["rejected"] = [];
    const seenRolls = new Map<number, number>();

    lines.forEach((line, idx) => {
      const rowNo = idx + 1;
      const cols = line.split(",").map((c) => c.trim());
      // Header row detection
      if (idx === 0 && cols[0] && !Number.isFinite(Number(cols[0]))) return;

      const fail = (reason: string) => rejected.push({ row: rowNo, reason });
      if (cols.length < 13) return fail(`expected 13 columns, found ${cols.length}`);

      const roll = Number(cols[0]);
      if (!Number.isFinite(roll) || roll <= 0) return fail(`roll '${cols[0]}' is not a positive number`);
      if (seenRolls.has(roll)) return fail(`duplicate roll ${roll} (first seen on row ${seenRolls.get(roll)})`);
      const name = cols[1];
      if (!name) return fail("name is empty");
      const classId = resolveClass(cols[2]);
      if (!classId) return fail(`unknown class '${cols[2]}' (use c9 or c10)`);
      const opt = resolveSubject(cols[3]);
      if (!opt) return fail(`unknown optional subject '${cols[3]}'`);

      const simple = [
        ["bangla", cols[4], 100],
        ["english", cols[5], 100],
        ["math", cols[6], 100],
        ["bgs", cols[9], 100],
        ["religion", cols[10], 100],
      ] as const;
      const parsed: Record<string, { absent: boolean; theory: number | null; practical: number | null }> = {};
      let bad = false;
      for (const [key, raw, max] of simple) {
        const r = parseMark(raw, max, key);
        if (!r.ok) {
          fail(r.reason);
          bad = true;
          continue;
        }
        parsed[key] =
          r.value === "AB"
            ? { absent: true, theory: null, practical: null }
            : { absent: false, theory: r.value, practical: null };
      }
      const sciT = parseMark(cols[7], 75, "science_theory");
      const sciP = parseMark(cols[8], 25, "science_practical");
      if (!sciT.ok) { fail(sciT.reason); bad = true; }
      if (!sciP.ok) { fail(sciP.reason); bad = true; }
      if (sciT.ok && sciP.ok) {
        parsed.science = {
          absent: sciT.value === "AB",
          theory: sciT.value === "AB" ? null : (sciT.value as number),
          practical: sciP.value === "AB" ? null : (sciP.value as number),
        };
      }
      const optT = parseMark(cols[11], opt.hasPractical ? 75 : 100, "optional_theory");
      if (!optT.ok) { fail(optT.reason); bad = true; }
      else {
        parsed[opt.id] = {
          absent: optT.value === "AB",
          theory: optT.value === "AB" ? null : (optT.value as number),
          practical: null,
        };
      }
      if (opt.hasPractical) {
        const optP = parseMark(cols[12] ?? "", 25, "optional_practical");
        if (!optP.ok) { fail(optP.reason); bad = true; }
        else if (parsed[opt.id]) parsed[opt.id].practical = optP.value === "AB" ? null : (optP.value as number);
      } else if ((cols[12] ?? "") !== "") {
        fail(`${opt.name} has no practical component, but optional_practical = '${cols[12]}'`);
        bad = true;
      }
      if (bad) return;

      seenRolls.set(roll, rowNo);
      const result = computeStudentResult(
        { id: `import-${roll}`, roll, name, classId, optionalSubjectId: opt.id, marks: parsed },
        ENGINE_CTX
      );
      accepted.push({ roll, name, gpa: result.finalGpa, letter: result.letter });
    });

    setOutcome({ accepted, rejected });
    setRan(true);
  };

  const downloadTemplate = () => {
    const blob = new Blob([SAMPLE_CSV], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "p08-marks-sheet-template.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <SectionTitle
        title="Import / paste marks sheet"
        desc="Bonus feature: paste a CSV marks sheet — every rejected row is reported with the exact reason before anything is published."
      />
      <div className="grid gap-5 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={10}
            placeholder={CSV_HEADER}
            className="font-mono text-xs"
            aria-label="CSV marks sheet"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button onClick={run} className="bg-emerald-700 hover:bg-emerald-800">
              Validate & compute
            </Button>
            <Button variant="outline" onClick={() => { setText(SAMPLE_CSV); setRan(false); }}>
              Load sample (with bad rows)
            </Button>
            <Button variant="outline" onClick={downloadTemplate}>
              Download template
            </Button>
          </div>
          <p className="mt-2 text-xs text-slate-400">
            Columns: {CSV_HEADER}. Use AB for an absent mark. science_theory is out of 75,
            science_practical out of 25; optional_theory is out of 75 for practical optionals
            (Physics, Chemistry, Biology, Higher Mathematics, ICT) and out of 100 for others
            (Geography, Agriculture).
          </p>
        </div>
        <div className="lg:col-span-2">
          {ran && outcome ? (
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-emerald-700">
                    Accepted rows: {outcome.accepted.length}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {outcome.accepted.length === 0 ? (
                    <p className="text-sm text-slate-400">No valid rows.</p>
                  ) : (
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-left text-xs uppercase text-slate-400">
                          <th className="py-1">Roll</th>
                          <th className="py-1">Name</th>
                          <th className="py-1 text-right">GPA</th>
                          <th className="py-1 text-right">Letter</th>
                        </tr>
                      </thead>
                      <tbody>
                        {outcome.accepted.map((a) => (
                          <tr key={a.roll} className="border-t border-slate-100">
                            <td className="py-1 font-mono text-xs">{a.roll}</td>
                            <td className="py-1">{a.name}</td>
                            <td className="py-1 text-right font-semibold">{a.gpa.toFixed(2)}</td>
                            <td className="py-1 text-right"><LetterBadge letter={a.letter} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </CardContent>
              </Card>
              <Card className="border-rose-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-rose-700">
                    Rejected rows: {outcome.rejected.length}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {outcome.rejected.length === 0 ? (
                    <p className="text-sm text-slate-400">Every row was accepted.</p>
                  ) : (
                    <ul className="space-y-1.5 text-sm">
                      {outcome.rejected.map((r, i) => (
                        <li key={i} className="rounded-md border border-rose-100 bg-rose-50 px-2 py-1 text-rose-800">
                          <b>Row {r.row}:</b> {r.reason}
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-slate-300 p-6 text-sm text-slate-400">
              Paste a marks sheet and press <b>Validate & compute</b>. Valid rows are computed
              instantly; invalid rows are listed with the exact reason (range, unknown subject,
              duplicate roll, missing value, AB misuse…).
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
