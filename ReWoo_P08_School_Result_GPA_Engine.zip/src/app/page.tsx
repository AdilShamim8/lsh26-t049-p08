"use client";

import { useState } from "react";
import { GraduationCap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { DashboardView, ClassesView, TraceView } from "@/components/p08/views-a";
import { ListsView, SummaryView, ImportView } from "@/components/p08/views-b";

type View = "dashboard" | "classes" | "trace" | "lists" | "summary" | "import";

const NAV: { id: View; label: string }[] = [
  { id: "dashboard", label: "Dashboard" },
  { id: "classes", label: "Classes" },
  { id: "trace", label: "Student Trace" },
  { id: "lists", label: "Checking Lists" },
  { id: "summary", label: "Class Summary" },
  { id: "import", label: "Import Sheet" },
];

export default function Home() {
  const [view, setView] = useState<View>("dashboard");
  const [studentId, setStudentId] = useState<string | null>("edge-1");

  const openStudent = (id: string) => {
    setStudentId(id);
    setView("trace");
  };

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur print:static print:border-0">
        <div className="mx-auto w-full max-w-6xl px-4 py-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-700 text-white">
                <GraduationCap className="h-6 w-6" aria-hidden="true" />
              </div>
              <div>
                <h1 className="text-base font-bold leading-tight tracking-tight sm:text-lg">
                  School Result Processing &amp; GPA Engine
                </h1>
                <p className="text-xs text-slate-500">
                  Bogura Secondary School · Deterministic rule engine with full calculation traces
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 print:hidden">
              <Badge variant="outline" className="border-emerald-200 bg-emerald-50 text-emerald-800">
                P08
              </Badge>
              <Badge variant="outline" className="text-slate-500">
                Team ReWoo · LofiStack 2026
              </Badge>
            </div>
          </div>

          {/* Nav */}
          <nav aria-label="Sections" className="mt-3 flex gap-1 overflow-x-auto pb-1 print:hidden">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                aria-current={view === n.id ? "page" : undefined}
                className={cn(
                  "whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition",
                  view === n.id
                    ? "bg-emerald-700 text-white shadow-sm"
                    : "text-slate-600 hover:bg-slate-100"
                )}
              >
                {n.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Main */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6">
        {view === "dashboard" && (
          <DashboardView
            onOpenStudent={openStudent}
            onGoLists={() => setView("lists")}
            onGoSummary={() => setView("summary")}
          />
        )}
        {view === "classes" && <ClassesView onOpenStudent={openStudent} />}
        {view === "trace" && (
          <TraceView studentId={studentId} onSelectStudent={setStudentId} />
        )}
        {view === "lists" && <ListsView onOpenStudent={openStudent} />}
        {view === "summary" && <SummaryView />}
        {view === "import" && <ImportView />}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white print:hidden">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-4 text-xs text-slate-500">
          <p>
            Team <b>ReWoo</b> · LofiStack Hackathon 2026 · Problem P08 — School Result Processing
            and GPA Engine
          </p>
          <p>Implements only the published rules: grade scale, R-11, R-12, R-13, R-10, R-29.</p>
        </div>
      </footer>
    </div>
  );
}
