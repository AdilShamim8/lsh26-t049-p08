import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "School Result Processing & GPA Engine — P08 | Team ReWoo",
  description:
    "LofiStack Hackathon 2026 P08 solution: deterministic school result processing and GPA engine with full per-subject calculation traces, pre-publication checking lists, and class summaries.",
  keywords: ["GPA engine", "school results", "P08", "LofiStack Hackathon 2026", "ReWoo"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
