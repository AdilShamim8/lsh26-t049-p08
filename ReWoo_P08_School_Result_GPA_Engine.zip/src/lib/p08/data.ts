/**
 * P08 seed data — deterministic, hand-crafted hard edges + fixed-seed
 * generated cohort. Same output on every load (judge-safe, hydration-safe).
 *
 * Cohort: 64 students across two classes (R1 requires ≥60 across 2 classes).
 * Every student: 6 compulsory subjects + exactly 1 optional subject.
 * General Science (compulsory) and Physics/Chemistry/Biology/Higher Math/ICT
 * (optional choices) carry separate theory (75) + practical (25) marks.
 */
import {
  ClassDef,
  SubjectDef,
  StudentInput,
  EngineContext,
  computeAllResults,
  StudentResult,
} from "./engine";

export const CLASSES: ClassDef[] = [
  { id: "c9", name: "Class 9 — Section A" },
  { id: "c10", name: "Class 10 — Section B" },
];

export const SUBJECTS: SubjectDef[] = [
  { id: "bangla", name: "Bangla", short: "BAN", compulsory: true, hasPractical: false },
  { id: "english", name: "English", short: "ENG", compulsory: true, hasPractical: false },
  { id: "math", name: "Mathematics", short: "MATH", compulsory: true, hasPractical: false },
  { id: "science", name: "General Science", short: "SCI", compulsory: true, hasPractical: true },
  { id: "bgs", name: "Bangladesh & Global Studies", short: "BGS", compulsory: true, hasPractical: false },
  { id: "religion", name: "Religion & Moral Education", short: "REL", compulsory: true, hasPractical: false },
  { id: "phy", name: "Physics", short: "PHY", compulsory: false, hasPractical: true },
  { id: "chem", name: "Chemistry", short: "CHEM", compulsory: false, hasPractical: true },
  { id: "bio", name: "Biology", short: "BIO", compulsory: false, hasPractical: true },
  { id: "hmath", name: "Higher Mathematics", short: "HMATH", compulsory: false, hasPractical: true },
  { id: "ict", name: "ICT", short: "ICT", compulsory: false, hasPractical: true },
  { id: "geo", name: "Geography & Environment", short: "GEO", compulsory: false, hasPractical: false },
  { id: "agr", name: "Agriculture Studies", short: "AGR", compulsory: false, hasPractical: false },
];

export const ENGINE_CTX: EngineContext = { subjects: SUBJECTS, classes: CLASSES };

const M = (theory: number | null, practical: number | null = null) =>
  ({ absent: false, theory, practical });
const AB = { absent: true, theory: null, practical: null };

/** Hand-crafted hard-edge students (R1 requires ≥8). */
const EDGE_STUDENTS: StudentInput[] = [
  {
    id: "edge-1", roll: 101, name: "Tanvir Ahmed", classId: "c9", optionalSubjectId: "phy",
    edgeNote: "High average but fails compulsory Mathematics (28/100) → final GPA 0.00, letter F, uncancelled average retained in trace.",
    marks: { bangla: M(88), english: M(82), math: M(28), science: M(60, 22), bgs: M(85), religion: M(90), phy: M(68, 24) },
  },
  {
    id: "edge-2", roll: 102, name: "Sadia Islam", classId: "c9", optionalSubjectId: "chem",
    edgeNote: "Practical fail with passing theory (Chemistry: theory 58/75 pass, practical 6/25 fail) → optional GP 0.",
    marks: { bangla: M(76), english: M(71), math: M(65), science: M(52, 16), bgs: M(74), religion: M(70), chem: M(58, 6) },
  },
  {
    id: "edge-3", roll: 103, name: "Rakib Hasan", classId: "c9", optionalSubjectId: "hmath",
    edgeNote: "Theory fail with passing practical (General Science: theory 20/75 fail, practical 18/25 pass) → compulsory subject fails.",
    marks: { bangla: M(66), english: M(58), math: M(61), science: M(20, 18), bgs: M(72), religion: M(63), hmath: M(70, 21) },
  },
  {
    id: "edge-4", roll: 201, name: "Nusrat Jahan", classId: "c10", optionalSubjectId: "ict",
    edgeNote: "Optional subject exactly at the helping point: ICT theory 30/75 + practical 15/25 = 45 → GP 2.0 → contributes max(0, 2.0 − 2) = 0, appears on optional checking list.",
    marks: { bangla: M(80), english: M(74), math: M(69), science: M(54, 18), bgs: M(77), religion: M(82), ict: M(30, 15) },
  },
  {
    id: "edge-5", roll: 104, name: "Mehedi Hasan", classId: "c9", optionalSubjectId: "bio",
    edgeNote: "Absent (AB) in compulsory English → GP 0, overall result F. AB is displayed differently from a zero mark.",
    marks: { bangla: M(78), english: AB, math: M(73), science: M(56, 19), bgs: M(68), religion: M(85), bio: M(61, 23) },
  },
  {
    id: "edge-6", roll: 202, name: "Farhana Akter", classId: "c10", optionalSubjectId: "bio",
    edgeNote: "Absent (AB) in optional Biology → contributes 0, appears on absent and optional checking lists.",
    marks: { bangla: M(84), english: M(79), math: M(71), science: M(58, 20), bgs: M(88), religion: M(90), bio: AB },
  },
  {
    id: "edge-7", roll: 105, name: "Jubayer Rahman", classId: "c9", optionalSubjectId: "geo",
    edgeNote: "Real zero mark (Bangla 0/100), NOT an absence → must output 0, not AB; overall F with visible failing subject.",
    marks: { bangla: M(0), english: M(55), math: M(48), science: M(41, 12), bgs: M(62), religion: M(59), geo: M(67) },
  },
  {
    id: "edge-8", roll: 203, name: "Ayesha Siddiqua", classId: "c10", optionalSubjectId: "chem",
    edgeNote: "GPA cap: raw (30 + 3) / 6 = 5.50 → capped at 5.00, letter A+.",
    marks: { bangla: M(92), english: M(89), math: M(95), science: M(70, 25), bgs: M(91), religion: M(94), chem: M(72, 25) },
  },
  {
    id: "edge-9", roll: 204, name: "Imran Kabir", classId: "c10", optionalSubjectId: "hmath",
    edgeNote: "Letter boundary: GPA exactly 4.00 → letter A (not A+).",
    marks: { bangla: M(72), english: M(71), math: M(75), science: M(53, 19), bgs: M(70), religion: M(55), hmath: M(38, 17) },
  },
  {
    id: "edge-10", roll: 106, name: "Sharmin Sultana", classId: "c9", optionalSubjectId: "agr",
    edgeNote: "Mark boundaries: Mathematics exactly 33 → GP 1.0 (pass); Bangla 79 → GP 4.0 (not 5.0).",
    marks: { bangla: M(79), english: M(47), math: M(33), science: M(40, 10), bgs: M(58), religion: M(44), agr: M(61) },
  },
];

// ---------------------------------------------------------------------------
// Deterministic cohort generation (fixed seed → identical on every load)
// ---------------------------------------------------------------------------

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const GENERATED_NAMES = [
  "Arif Chowdhury", "Saima Haque", "Nabil Hossain", "Mita Roy", "Rahim Uddin",
  "Priya Das", "Sabbir Ahmed", "Tania Begum", "Hasan Mahmud", "Rima Khatun",
  "Zahid Islam", "Nila Sarker", "Toufiq Alam", "Shila Rani", "Kamal Hossain",
  "Rumi Akter", "Sohel Rana", "Nasrin Sultana", "Jahid Hasan", "Tuli Das",
  "Rafiq Mollah", "Sultana Razia", "Babu Sheikh", "Mim Chowdhury", "Sumon Mia",
  "Laila Arjuman", "Nazmul Huda", "Rina Pal", "Iqbal Bahar", "Shiuli Begum",
  "Anisur Rahman", "Joya Sarker", "Delwar Hossain", "Parul Akter", "Sajid Khan",
  "Ruma Parvin", "Tariq Anwar", "Mousumi Haque", "Alamgir Kabir", "Shirin Bala",
  "Fazlul Karim", "Nazma Bibi", "Habibur Rahman", "Keya Chowdhury", "Mahfuz Ahmed",
  "Dola Sarker", "Yunus Ali", "Shefali Ghosh", "Jahangir Alam", "Rokeya Begum",
  "Nayeem Siddik", "Ankhi Das", "Zaman Sheikh", "Halima Khatun",
];

const OPTIONAL_IDS = ["phy", "chem", "bio", "hmath", "ict", "geo", "agr"];

function generateStudents(): StudentInput[] {
  const rand = mulberry32(20260830);
  const students: StudentInput[] = [];
  let nameIdx = 0;

  const genFor = (classId: string, fromRoll: number, count: number) => {
    for (let i = 0; i < count; i++) {
      const ability = 0.55 + rand() * 0.4; // 0.55–0.95
      const noise = () => Math.round((rand() - 0.5) * 14);
      const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
      // ~12% of the generated cohort struggles: some marks land in the fail band
      // so class summaries and checking lists reflect a realistic spread.
      const struggle = rand() < 0.12;
      const mark100 = () =>
        struggle && rand() < 0.45
          ? clamp(Math.round(rand() * 32), 5, 32)
          : clamp(Math.round(ability * 100 + noise()), 31, 98);
      const theory75 = () =>
        struggle && rand() < 0.45
          ? clamp(Math.round(rand() * 25) + 15, 15, 39)
          : clamp(Math.round(ability * 75 + noise() * 0.75), 28, 74);
      const practical25 = () => clamp(Math.round(ability * 25 + noise() * 0.4), 9, 25);

      const optionalId = OPTIONAL_IDS[(nameIdx + i) % OPTIONAL_IDS.length];
      const optionalDef = SUBJECTS.find((s) => s.id === optionalId)!;
      const optMarks = optionalDef.hasPractical
        ? M(clamp(theory75() + 4, 28, 74), practical25())
        : M(mark100());

      const marks: Record<string, StudentInput["marks"][string]> = {
        bangla: M(mark100()),
        english: M(mark100()),
        math: M(mark100()),
        science: M(theory75(), practical25()),
        bgs: M(mark100()),
        religion: M(mark100()),
        [optionalId]: optMarks,
      };

      students.push({
        id: `${classId}-g${i + 1}`,
        roll: fromRoll + i,
        name: GENERATED_NAMES[nameIdx++ % GENERATED_NAMES.length],
        classId,
        optionalSubjectId: optionalId,
        marks,
      });
    }
  };

  genFor("c9", 107, 26); // rolls 107–132
  genFor("c10", 205, 28); // rolls 205–232
  return students;
}

export const STUDENTS: StudentInput[] = [...EDGE_STUDENTS, ...generateStudents()].sort(
  (a, b) => a.classId.localeCompare(b.classId) || a.roll - b.roll
);

// ---------------------------------------------------------------------------
// Memoised full results (pure computation over deterministic data)
// ---------------------------------------------------------------------------

let cached: StudentResult[] | null = null;

export function getAllResults(): StudentResult[] {
  if (!cached) cached = computeAllResults(STUDENTS, ENGINE_CTX);
  return cached;
}

export function getResultsByClass(classId: string): StudentResult[] {
  return getAllResults().filter((r) => r.student.classId === classId);
}

export function getResultById(studentId: string): StudentResult | undefined {
  return getAllResults().find((r) => r.student.id === studentId);
}

export const EDGE_STUDENTS_ONLY = EDGE_STUDENTS;
