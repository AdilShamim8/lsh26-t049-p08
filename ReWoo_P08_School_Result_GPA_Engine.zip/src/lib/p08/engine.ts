/**
 * P08 — School Result Processing and GPA Engine
 * Pure, deterministic calculation layer implementing ONLY the rules
 * published in the LofiStack Hackathon 2026 P08 brief:
 *   R-10 letter grades, grading scale, R-11 practical rules,
 *   R-12 absence rules, R-13 GPA formula, R-29 checking lists.
 * No randomness, no hidden configuration — every number is auditable.
 */

export interface SubjectDef {
  id: string;
  name: string;
  short: string;
  compulsory: boolean;
  hasPractical: boolean;
}

export interface MarkEntry {
  /** true → the student was absent (AB). Distinct from a real 0 mark. */
  absent: boolean;
  /** Non-practical subject: mark out of 100. Practical subject: theory out of 75. */
  theory: number | null;
  /** Practical mark out of 25. null when subject has no practical component. */
  practical: number | null;
}

export interface StudentInput {
  id: string;
  roll: number;
  name: string;
  classId: string;
  /** Optional (4th) subject chosen by the student. */
  optionalSubjectId: string;
  marks: Record<string, MarkEntry>;
  /** Describes the deliberately seeded hard edge, if any. */
  edgeNote?: string;
}

export interface ClassDef {
  id: string;
  name: string;
}

export interface SubjectTrace {
  subjectId: string;
  subjectName: string;
  compulsory: boolean;
  hasPractical: boolean;
  absent: boolean;
  theory: number | null;
  theoryMax: number;
  practical: number | null;
  practicalMax: number | null;
  /** Mark the grade was computed from (theory+practical for practical subjects). */
  markUsed: number | null;
  gradePoint: number;
  passed: boolean;
  failureReason: string | null;
  /** Human-readable rule, using the student's real numbers. */
  ruleText: string;
  /** Compulsory: grade point. Optional: max(0, grade point − 2). */
  contribution: number;
}

export interface StudentResult {
  student: StudentInput;
  className: string;
  traces: SubjectTrace[];
  compulsorySum: number;
  optionalSubjectName: string;
  optionalGradePoint: number;
  optionalContribution: number;
  compulsoryFailed: boolean;
  failedCompulsorySubjects: { subject: string; reason: string }[];
  /** (Σ compulsory GP + max(0, optional GP − 2)) / 6, capped at 5.00. */
  uncancelledGpa: number;
  uncancelledRaw: number;
  finalGpa: number;
  letter: string;
  checking: {
    optionalList: boolean;
    practicalFailList: boolean;
    absentList: boolean;
    reasons: string[];
  };
}

// ---------------------------------------------------------------------------
// Rules
// ---------------------------------------------------------------------------

export const THEORY_MAX = 75;
export const PRACTICAL_MAX = 25;
export const THEORY_PASS = 25;
export const PRACTICAL_PASS = 8;
export const FULL_MARK_NON_PRACTICAL = 100;

/** Standard grading scale (P08 brief table). */
export function gradePointForMark(mark: number): { gp: number; rule: string } {
  if (mark >= 80) return { gp: 5.0, rule: `Mark ${mark} → 80 and above → grade point 5.0` };
  if (mark >= 70) return { gp: 4.0, rule: `Mark ${mark} → 70–79 → grade point 4.0` };
  if (mark >= 60) return { gp: 3.5, rule: `Mark ${mark} → 60–69 → grade point 3.5` };
  if (mark >= 50) return { gp: 3.0, rule: `Mark ${mark} → 50–59 → grade point 3.0` };
  if (mark >= 40) return { gp: 2.0, rule: `Mark ${mark} → 40–49 → grade point 2.0` };
  if (mark >= 33) return { gp: 1.0, rule: `Mark ${mark} → 33–39 → grade point 1.0` };
  return { gp: 0.0, rule: `Mark ${mark} → below 33 → grade point 0.0 (fail)` };
}

/** R-10 final letter grades, applied to the 2-decimal displayed GPA. */
export function letterForGpa(gpa: number): string {
  if (gpa >= 5.0) return "A+";
  if (gpa >= 4.0) return "A";
  if (gpa >= 3.5) return "A-";
  if (gpa >= 3.0) return "B";
  if (gpa >= 2.0) return "C";
  if (gpa >= 1.0) return "D";
  return "F";
}

export function round2(x: number): number {
  return Math.round((x + Number.EPSILON) * 100) / 100;
}

// ---------------------------------------------------------------------------
// Subject evaluation
// ---------------------------------------------------------------------------

function evaluateSubject(
  student: StudentInput,
  subject: SubjectDef,
  optionalSubject: SubjectDef
): SubjectTrace {
  const isOptional = subject.id === optionalSubject.id;
  const mark = student.marks[subject.id];
  const base: SubjectTrace = {
    subjectId: subject.id,
    subjectName: subject.name,
    compulsory: subject.compulsory,
    hasPractical: subject.hasPractical,
    absent: false,
    theory: mark?.theory ?? null,
    theoryMax: subject.hasPractical ? THEORY_MAX : FULL_MARK_NON_PRACTICAL,
    practical: mark?.practical ?? null,
    practicalMax: subject.hasPractical ? PRACTICAL_MAX : null,
    markUsed: null,
    gradePoint: 0,
    passed: true,
    failureReason: null,
    ruleText: "",
    contribution: 0,
  };

  // Missing mark entry is treated as absent (seed/import guarantees presence).
  if (!mark || mark.absent) {
    base.absent = true;
    base.passed = false;
    base.failureReason = "Absent";
    base.gradePoint = 0;
    base.contribution = 0;
    base.ruleText = subject.compulsory
      ? "R-12: Absent in a compulsory subject → shown as AB, grade point 0, overall result F. AB is not a zero mark."
      : "R-12: Absent in the optional subject → shown as AB, contributes 0, student appears on the checking lists.";
    return base;
  }

  if (subject.hasPractical) {
    const theory = mark.theory ?? 0;
    const practical = mark.practical ?? 0;
    const theoryFailed = theory < THEORY_PASS;
    const practicalFailed = practical < PRACTICAL_PASS;

    if (theoryFailed || practicalFailed) {
      base.theory = theory;
      base.practical = practical;
      base.passed = false;
      base.gradePoint = 0;
      base.markUsed = null;
      base.failureReason = theoryFailed
        ? `Theory ${theory}/${THEORY_MAX} is below the pass mark ${THEORY_PASS}`
        : `Practical ${practical}/${PRACTICAL_MAX} is below the pass mark ${PRACTICAL_PASS}`;
      base.ruleText = `R-11: Theory ${theory}/${THEORY_MAX}, Practical ${practical}/${PRACTICAL_MAX}. Student must pass BOTH parts separately (theory ≥ ${THEORY_PASS}, practical ≥ ${PRACTICAL_PASS}); failing either part gives grade point 0. Result: FAIL — ${base.failureReason}.`;
      return base;
    }

    const total = theory + practical;
    const { gp, rule } = gradePointForMark(total);
    base.theory = theory;
    base.practical = practical;
    base.markUsed = total;
    base.gradePoint = gp;
    base.passed = true;
    base.ruleText = `R-11 passed both parts → Theory ${theory}/${THEORY_MAX} + Practical ${practical}/${PRACTICAL_MAX} = ${total}. ${rule}.`;
    base.contribution = isOptional ? Math.max(0, gp - 2) : gp;
    return base;
  }

  const total = mark.theory ?? 0;
  const { gp, rule } = gradePointForMark(total);
  base.markUsed = total;
  base.gradePoint = gp;
  base.passed = gp > 0;
  base.ruleText = `${rule}.`;
  base.contribution = isOptional ? Math.max(0, gp - 2) : gp;
  return base;
}

// ---------------------------------------------------------------------------
// Full student result
// ---------------------------------------------------------------------------

export interface EngineContext {
  subjects: SubjectDef[];
  classes: ClassDef[];
}

export function computeStudentResult(
  student: StudentInput,
  ctx: EngineContext
): StudentResult {
  const optionalSubject =
    ctx.subjects.find((s) => s.id === student.optionalSubjectId) ?? ctx.subjects[0];
  const subjectOrder = ctx.subjects.filter(
    (s) => s.compulsory || s.id === optionalSubject.id
  );
  const traces = subjectOrder.map((s) => evaluateSubject(student, s, optionalSubject));

  const compulsoryTraces = traces.filter((t) => t.compulsory);
  const optionalTrace = traces.find((t) => !t.compulsory)!;

  const compulsorySum = round2(
    compulsoryTraces.reduce((sum, t) => sum + t.gradePoint, 0)
  );
  const optionalContribution = Math.max(0, optionalTrace.gradePoint - 2);
  const rawGpa = (compulsorySum + optionalContribution) / 6;
  const uncancelledRaw = round2(rawGpa);
  const uncancelledGpa = round2(Math.min(5.0, rawGpa));

  const failedCompulsorySubjects = compulsoryTraces
    .filter((t) => !t.passed)
    .map((t) => ({ subject: t.subjectName, reason: t.failureReason ?? "Failed" }));
  const compulsoryFailed = failedCompulsorySubjects.length > 0;

  const finalGpa = compulsoryFailed ? 0 : uncancelledGpa;
  const letter = compulsoryFailed ? "F" : letterForGpa(finalGpa);

  // R-29 checking lists
  const reasons: string[] = [];
  const optionalList = optionalTrace.gradePoint <= 2.0;
  if (optionalList) {
    if (optionalTrace.absent) {
      reasons.push(`Optional subject ${optionalTrace.subjectName}: AB → contributes 0`);
    } else {
      reasons.push(
        `Optional subject ${optionalTrace.subjectName}: grade point ${optionalTrace.gradePoint.toFixed(1)} (≤ 2.0) → contributes max(0, ${optionalTrace.gradePoint.toFixed(1)} − 2) = 0`
      );
    }
  }
  const practicalFailList = traces.some(
    (t) =>
      t.hasPractical &&
      !t.absent &&
      t.practical !== null &&
      t.practical < PRACTICAL_PASS
  );
  if (practicalFailList) {
    const bad = traces.filter(
      (t) => t.hasPractical && !t.absent && t.practical !== null && t.practical < PRACTICAL_PASS
    );
    reasons.push(
      `Practical below 8: ${bad.map((t) => `${t.subjectName} (${t.practical}/${PRACTICAL_MAX})`).join(", ")}`
    );
  }
  const absentList = traces.some((t) => t.absent);
  if (absentList) {
    const absents = traces.filter((t) => t.absent);
    reasons.push(
      `Absent (AB): ${absents.map((t) => `${t.subjectName}${t.compulsory ? " (compulsory)" : " (optional)"}`).join(", ")}`
    );
  }

  return {
    student,
    className: ctx.classes.find((c) => c.id === student.classId)?.name ?? student.classId,
    traces,
    compulsorySum,
    optionalSubjectName: optionalSubject.name,
    optionalGradePoint: optionalTrace.gradePoint,
    optionalContribution,
    compulsoryFailed,
    failedCompulsorySubjects,
    uncancelledGpa,
    uncancelledRaw,
    finalGpa,
    letter,
    checking: {
      optionalList,
      practicalFailList,
      absentList,
      reasons,
    },
  };
}

export function computeAllResults(
  students: StudentInput[],
  ctx: EngineContext
): StudentResult[] {
  return students.map((s) => computeStudentResult(s, ctx));
}

// ---------------------------------------------------------------------------
// Aggregates for class summary
// ---------------------------------------------------------------------------

export interface ClassSummaryStats {
  classId: string;
  className: string;
  students: number;
  passed: number;
  failed: number;
  passRate: number; // 0-100, 2 decimals
  averageGpa: number; // passed students only
  aPlusCount: number;
  gradeDistribution: Record<string, number>; // A+..F → count
  subjectFailureCounts: { subject: string; failures: number }[];
  worstSubject: { subject: string; failures: number } | null;
}

export function summarizeClass(
  results: StudentResult[],
  classId: string
): ClassSummaryStats {
  const inClass = results.filter((r) => r.student.classId === classId);
  const className = inClass[0]?.className ?? classId;
  const passed = inClass.filter((r) => !r.compulsoryFailed);
  const dist: Record<string, number> = { "A+": 0, A: 0, "A-": 0, B: 0, C: 0, D: 0, F: 0 };
  inClass.forEach((r) => {
    dist[r.letter] = (dist[r.letter] ?? 0) + 1;
  });
  const failBySubject = new Map<string, number>();
  inClass.forEach((r) =>
    r.traces.forEach((t) => {
      if (t.compulsory && !t.passed) {
        failBySubject.set(t.subjectName, (failBySubject.get(t.subjectName) ?? 0) + 1);
      }
    })
  );
  const subjectFailureCounts = [...failBySubject.entries()]
    .map(([subject, failures]) => ({ subject, failures }))
    .sort((a, b) => b.failures - a.failures);

  return {
    classId,
    className,
    students: inClass.length,
    passed: passed.length,
    failed: inClass.length - passed.length,
    passRate: inClass.length ? round2((passed.length / inClass.length) * 100) : 0,
    averageGpa: passed.length
      ? round2(passed.reduce((s, r) => s + r.finalGpa, 0) / passed.length)
      : 0,
    aPlusCount: inClass.filter((r) => r.letter === "A+").length,
    gradeDistribution: dist,
    subjectFailureCounts,
    worstSubject: subjectFailureCounts[0] ?? null,
  };
}
