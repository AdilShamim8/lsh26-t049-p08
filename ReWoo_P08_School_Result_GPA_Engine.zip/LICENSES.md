# Third-Party Licenses

All third-party items used by this project, with the licenses they carry. None of them are
copyleft (AGPL/GPL/LGPL/MPL/SSPL) or non-commercial; all are usable in this hackathon submission.

## Direct runtime dependencies

| Item | Version | Source | License | Usage |
|---|---|---|---|---|
| next | ^16.1.1 | npm | MIT | App framework (App Router) |
| react / react-dom | ^19.0.0 | npm | MIT | UI runtime |
| lucide-react | ^0.525.0 | npm | ISC | Icons (header graduation-cap icon) |
| clsx | ^2.1.1 | npm | MIT | Conditional class names |
| tailwind-merge | ^3.3.1 | npm | MIT | Class-name merging (`cn` helper) |
| class-variance-authority | ^0.7.1 | npm | Apache-2.0 | shadcn/ui component variants |
| @radix-ui/react-* (select, slot, etc.) | various | npm | MIT | Headless primitives inside shadcn/ui components actually rendered (Select, Badge, Button, Card, Textarea internals) |
| tailwindcss | ^4 (dev) | npm | MIT | Styling |
| tw-animate-css | ^1.3.5 | npm | MIT | Animation utilities imported by globals.css |
| typescript / eslint (+ eslint-config-next) | ^5 / ^9 | npm | Apache-2.0 / MIT | Tooling only, not shipped |

## Templates / assets

| Item | Version | Source | License | Usage |
|---|---|---|---|---|
| shadcn/ui (New York style) component sources | current | ui.shadcn.com | MIT | Base for the rendered UI components (copied into `src/components/ui`) |
| Geist font (via `next/font/google`) | current | Vercel | SIL OFL 1.1 | UI typography |

## Notes

- The application logic (result engine, seed data, views, verification script) is original work
  produced by Team ReWoo for this event.
- The Prisma/NextAuth/TanStack packages present in the scaffold's `package.json` are **not used**
  by this project's runtime; only the items listed above are exercised.
- No employer/client-owned code or non-commercial assets are included.
