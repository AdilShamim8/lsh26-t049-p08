# School Result Processing & GPA Engine — P08

**LofiStack Hackathon 2026 · Team ReWoo · Problem P08 (Tier 02, Community)**

## Problem

A secondary school in Bogura works out final results manually in a spreadsheet. Grading becomes
complicated with an optional fourth subject, practical components, failure rules and absences —
and errors are usually discovered only when a parent walks into the office.

## Solution

A deterministic, auditable result engine. It takes raw marks, produces final results using **only
the rules published in the P08 brief**, shows the teacher exactly **which rule produced every
number**, and catches wrong entries **before** results are published.

- **Live demo:** open the deployed URL (single page, no login, no setup).
- **Seed data:** 64 students across 2 classes, every student with 6 compulsory subjects + 1
  optional subject, separate theory/practical marks for practical subjects, and **10 deliberately
  seeded hard-edge students** (marked ★ in the UI).

## Key features (mapped to scored requirements)

| Requirement | Where to see it |
|---|---|
| **R1 — Data scale & edge cases** | Dashboard shows the 64-student/2-class cohort; the "Hard-edge students" section lists all 10 boundary cases (≥8 required) with explanations. |
| **R2 — Correct results** | Every student's subject grade points, final GPA (2 dp, capped at 5.00) and letter grade (R-10) on the Classes tab and each trace. |
| **R3 — Per-student trace** | Student Trace tab: for every subject, the exact mark used (theory/practical split where applicable), the grade point produced and the rule sentence that decided it, plus a full R-13 GPA walk-through. |
| **R4 — Checking lists** | Checking Lists tab: optional-subject list (GP ≤ 2.0), practical-fail list (< 8/25), absent list (AB) — with the exact reason for every membership; students can appear on multiple lists. |
| Bonus — Class summary | Pass rate, grade distribution, subject with the most failures, per class. |
| Bonus — Marks-sheet import | Import Sheet tab: paste CSV; every rejected row is reported with the exact reason (range, unknown subject, duplicate roll, AB misuse…). |

## How to run

```bash
bun install        # or npm install
bun run dev        # http://localhost:3000
```

Production: `bun run build && bun run start` (standard Next.js 16 standalone build).

## Sample data

The published-style cohort is **built in** (deterministic, fixed-seed generation + hand-crafted
edge cases) — every page load shows the same auditable data. Reset = refresh the page. The
Import Sheet tab accepts a CSV marks sheet in the documented column format (template
downloadable there); invalid rows are rejected with exact reasons and never published.

## What is mocked

Nothing in the calculation chain is mocked or hard-coded: all results, traces, lists and summaries
are computed at runtime by the pure engine in `src/lib/p08/engine.ts` from the seed marks in
`src/lib/p08/data.ts`. The school itself is the fictional Bogura Secondary School from the brief;
there is no backend persistence (results are recomputed from the same deterministic seed).

## What we would build next

1. Persist entered marks (DB) with teacher accounts and an audit log of edits.
2. Support multiple exams per year (first terminal, mid-term, final) with weighting.
3. Export official printable marksheet PDFs and a principal sign-off flow.
4. Fixture file upload (portal JSON) in addition to the CSV paste path.

## Known limitations

- Data is in-memory and deterministic; a judge cannot permanently alter the cohort (by design for
  judging safety — reload restores the published state).
- The CSV importer validates and previews results; it does not merge imported students into the
  main cohort views.
- Bangla subject names are in English only.

## Engine rule map (verbatim implementation)

- Grade scale: 80+ → 5.0, 70–79 → 4.0, 60–69 → 3.5, 50–59 → 3.0, 40–49 → 2.0, 33–39 → 1.0, <33 → 0.0 + fail.
- **R-11:** theory /75 (pass ≥ 25), practical /25 (pass ≥ 8); both must pass; either fail → GP 0.
- **R-12:** absent compulsory → `AB`, GP 0, overall F; absent optional → contributes 0 + checking list; AB ≠ 0.
- **R-13:** GPA = (Σ compulsory GP + max(0, optional GP − 2)) / 6, cap 5.00, 2 dp; compulsory failure → GPA 0.00, letter F, uncancelled average retained in trace.
- **R-10:** 5.00 → A+, 4.00–4.99 → A, 3.50–3.99 → A-, 3.00–3.49 → B, 2.00–2.99 → C, 1.00–1.99 → D, fail → F.
- **R-29:** three checking lists as defined in the brief.

## Verification

`scripts/verify-p08.ts` asserts hand-computed expectations for every edge case (uncancelled vs
final GPA, list memberships, AB vs zero, boundaries 33/79/80, cap 5.00, exact-4.00 → A) and a
whole-cohort re-derivation of the R-13 formula. Run with `bun scripts/verify-p08.ts`.
