/**
 * P08 engine verification — asserts hand-computed expectations for every
 * seeded hard-edge student plus structural invariants for the whole cohort.
 * Run: bun scripts/verify-p08.ts
 */
import { getAllResults, ENGINE_CTX, STUDENTS } from "../src/lib/p08/data";

let failures = 0;
function expect(cond: boolean, label: string) {
  if (cond) {
    console.log(`  PASS  ${label}`);
  } else {
    failures++;
    console.error(`  FAIL  ${label}`);
  }
}
function approx(a: number, b: number) {
  return Math.abs(a - b) < 1e-9;
}

console.log("— Structural invariants (R1) —");
expect(STUDENTS.length >= 60, `cohort ≥ 60 students (got ${STUDENTS.length})`);
const classes = new Set(STUDENTS.map((s) => s.classId));
expect(classes.size === 2, `exactly 2 classes (got ${classes.size})`);
const allSeven = STUDENTS.every((s) => {
  const opt = ENGINE_CTX.subjects.find((x) => x.id === s.optionalSubjectId)!;
  const comp = ENGINE_CTX.subjects.filter((x) => x.compulsory);
  return comp.every((c) => !!s.marks[c.id]) && !!s.marks[opt.id] && comp.length === 6;
});
expect(allSeven, "every student has 6 compulsory subjects + 1 optional with marks");
const edges = STUDENTS.filter((s) => s.edgeNote);
expect(edges.length >= 8, `≥ 8 hard-edge students (got ${edges.length})`);
expect(
  STUDENTS.some((s) => s.marks.english?.absent),
  "absent (AB) case seeded in a compulsory subject"
);
expect(
  STUDENTS.some((s) => s.marks.bangla && !s.marks.bangla.absent && s.marks.bangla.theory === 0),
  "real zero mark (0, not AB) seeded"
);

console.log("— Hard-edge expectations (R2/R3/R4, R-11..R-13, R-29) —");
const R = (id: string) => getAllResults().find((r) => r.student.id === id)!;

// E1 Tanvir — high average, compulsory math fail
const e1 = R("edge-1");
expect(approx(e1.uncancelledGpa, 4.67), `E1 uncancelled GPA = 4.67 (got ${e1.uncancelledGpa})`);
expect(e1.finalGpa === 0 && e1.letter === "F", `E1 final 0.00 / F (got ${e1.finalGpa}/${e1.letter})`);
expect(
  e1.failedCompulsorySubjects[0]?.subject === "Mathematics",
  "E1 failing compulsory subject = Mathematics"
);
expect(
  e1.traces.find((t) => t.subjectName === "Mathematics")?.ruleText.includes("28"),
  "E1 trace uses real numbers (mark 28)"
);

// E2 Sadia — practical fail, passing theory (optional chemistry)
const e2 = R("edge-2");
expect(approx(e2.finalGpa, 3.83), `E2 GPA = 3.83 (got ${e2.finalGpa})`);
expect(e2.letter === "A-", `E2 letter A- (got ${e2.letter})`);
expect(e2.checking.practicalFailList, "E2 on practical fail list");
expect(e2.checking.optionalList, "E2 on optional list (GP 0)");

// E3 Rakib — theory fail with passing practical (compulsory science)
const e3 = R("edge-3");
expect(e3.compulsoryFailed && e3.letter === "F", "E3 compulsory fail → F");
expect(
  e3.traces.find((t) => t.subjectName === "General Science")?.failureReason?.includes("Theory"),
  "E3 science fails on theory (<25)"
);
expect(!e3.checking.practicalFailList, "E3 NOT on practical fail list (practical 18 ≥ 8)");

// E4 Nusrat — optional exactly at 2.0
const e4 = R("edge-4");
expect(approx(e4.optionalGradePoint, 2.0), `E4 optional GP = 2.0 (got ${e4.optionalGradePoint})`);
expect(approx(e4.optionalContribution, 0), "E4 optional contribution = 0");
expect(e4.checking.optionalList, "E4 on optional list");
expect(approx(e4.finalGpa, 4.25) && e4.letter === "A", `E4 4.25/A (got ${e4.finalGpa}/${e4.letter})`);

// E5 Mehedi — absent compulsory English
const e5 = R("edge-5");
const engTrace = e5.traces.find((t) => t.subjectName === "English")!;
expect(engTrace.absent && engTrace.gradePoint === 0, "E5 English AB, GP 0");
expect(e5.finalGpa === 0 && e5.letter === "F", "E5 final 0.00/F");
expect(e5.checking.absentList, "E5 on absent list");
expect(approx(e5.uncancelledGpa, 3.92), `E5 uncancelled 3.92 (got ${e5.uncancelledGpa})`);

// E6 Farhana — absent optional biology
const e6 = R("edge-6");
const bioTrace = e6.traces.find((t) => t.subjectName === "Biology")!;
expect(bioTrace.absent, "E6 Biology AB");
expect(e6.checking.absentList && e6.checking.optionalList, "E6 on absent AND optional lists");
expect(approx(e6.finalGpa, 4.5) && e6.letter === "A", `E6 4.50/A (got ${e6.finalGpa}/${e6.letter})`);

// E7 Jubayer — real zero, not AB
const e7 = R("edge-7");
const banTrace = e7.traces.find((t) => t.subjectName === "Bangla")!;
expect(!banTrace.absent && banTrace.markUsed === 0 && banTrace.gradePoint === 0, "E7 Bangla 0 mark (not AB), GP 0");
expect(e7.finalGpa === 0 && e7.letter === "F", "E7 final 0.00/F");

// E8 Ayesha — cap at 5.00
const e8 = R("edge-8");
expect(approx(e8.uncancelledRaw, 5.5), `E8 raw GPA = 5.50 (got ${e8.uncancelledRaw})`);
expect(approx(e8.uncancelledGpa, 5.0), `E8 capped at 5.00 (got ${e8.uncancelledGpa})`);
expect(e8.letter === "A+", "E8 letter A+");

// E9 Imran — exactly 4.00 → A (not A+)
const e9 = R("edge-9");
expect(approx(e9.finalGpa, 4.0), `E9 GPA exactly 4.00 (got ${e9.finalGpa})`);
expect(e9.letter === "A", `E9 letter A not A+ (got ${e9.letter})`);

// E10 Sharmin — boundaries 33 → 1.0 pass; 79 → 4.0
const e10 = R("edge-10");
const mathTrace = e10.traces.find((t) => t.subjectName === "Mathematics")!;
expect(mathTrace.gradePoint === 1.0 && mathTrace.passed, "E10 math 33 → GP 1.0, passes");
const banTrace10 = e10.traces.find((t) => t.subjectName === "Bangla")!;
expect(banTrace10.gradePoint === 4.0, "E10 Bangla 79 → GP 4.0 (not 5.0)");
expect(approx(e10.finalGpa, 2.75) && e10.letter === "C", `E10 2.75/C (got ${e10.finalGpa}/${e10.letter})`);

console.log("— Whole-cohort invariants —");
const results = getAllResults();
let consistent = true;
for (const r of results) {
  const sum = r.traces.filter((t) => t.compulsory).reduce((s, t) => s + t.gradePoint, 0);
  const raw = (sum + Math.max(0, r.optionalGradePoint - 2)) / 6;
  const capped = Math.min(5, raw);
  const gpa = r.compulsoryFailed ? 0 : Math.round(capped * 100) / 100;
  if (Math.abs(gpa - r.finalGpa) > 0.005) {
    consistent = false;
    console.error(`  GPA mismatch for ${r.student.name}: engine ${r.finalGpa} vs manual ${gpa}`);
  }
  if (r.finalGpa > 5.0 || r.finalGpa < 0) consistent = false;
}
expect(consistent, "engine GPA matches the published formula for all 64 students");

const abStudent = results.find((r) => r.student.id === "edge-5")!;
const zeroStudent = results.find((r) => r.student.id === "edge-7")!;
expect(
  abStudent.traces.some((t) => t.absent) && zeroStudent.traces.every((t) => !t.absent),
  "AB and zero-mark students produce different traces"
);

console.log(failures === 0 ? "\nALL CHECKS PASSED" : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
